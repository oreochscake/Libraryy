﻿namespace LibraryManagementSystem
{
    partial class Dashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            panel3 = new Panel();
            panel4 = new Panel();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            panel5 = new Panel();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            panel6 = new Panel();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(12, 18);
            panel1.Name = "panel1";
            panel1.Size = new Size(855, 217);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(46, 0, 70);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(17, 13);
            panel2.Name = "panel2";
            panel2.Size = new Size(247, 187);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(78, 80);
            label1.Name = "label1";
            label1.Size = new Size(163, 28);
            label1.TabIndex = 0;
            label1.Text = "Available Books";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.Image = Properties.Resources.hihihi2;
            label2.Location = new Point(12, 64);
            label2.Name = "label2";
            label2.Size = new Size(60, 60);
            label2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.WhiteSmoke;
            label3.Location = new Point(207, 141);
            label3.Name = "label3";
            label3.Size = new Size(40, 46);
            label3.TabIndex = 2;
            label3.Text = "0";
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ButtonHighlight;
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(-1, -1);
            panel3.Name = "panel3";
            panel3.Size = new Size(855, 217);
            panel3.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(46, 0, 70);
            panel4.Controls.Add(label4);
            panel4.Controls.Add(label5);
            panel4.Controls.Add(label6);
            panel4.Location = new Point(17, 13);
            panel4.Name = "panel4";
            panel4.Size = new Size(247, 187);
            panel4.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.WhiteSmoke;
            label4.Location = new Point(207, 141);
            label4.Name = "label4";
            label4.Size = new Size(40, 46);
            label4.TabIndex = 2;
            label4.Text = "0";
            // 
            // label5
            // 
            label5.Image = Properties.Resources.tae;
            label5.Location = new Point(12, 64);
            label5.Name = "label5";
            label5.Size = new Size(60, 60);
            label5.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.WhiteSmoke;
            label6.Location = new Point(78, 80);
            label6.Name = "label6";
            label6.Size = new Size(163, 28);
            label6.TabIndex = 0;
            label6.Text = "Available Books";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(46, 0, 70);
            panel5.Controls.Add(label7);
            panel5.Controls.Add(label9);
            panel5.Controls.Add(label11);
            panel5.Location = new Point(307, 13);
            panel5.Name = "panel5";
            panel5.Size = new Size(247, 187);
            panel5.TabIndex = 3;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.WhiteSmoke;
            label7.Location = new Point(207, 141);
            label7.Name = "label7";
            label7.Size = new Size(40, 46);
            label7.TabIndex = 2;
            label7.Text = "0";
            // 
            // label8
            // 
            label8.Image = Properties.Resources.hihihi2;
            label8.Location = new Point(12, 64);
            label8.Name = "label8";
            label8.Size = new Size(60, 60);
            label8.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.WhiteSmoke;
            label9.Location = new Point(96, 80);
            label9.Name = "label9";
            label9.Size = new Size(134, 28);
            label9.TabIndex = 0;
            label9.Text = "Issued Books";
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(46, 0, 70);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(label8);
            panel6.Controls.Add(label12);
            panel6.Location = new Point(590, 13);
            panel6.Name = "panel6";
            panel6.Size = new Size(247, 187);
            panel6.TabIndex = 3;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.WhiteSmoke;
            label10.Location = new Point(207, 141);
            label10.Name = "label10";
            label10.Size = new Size(40, 46);
            label10.TabIndex = 2;
            label10.Text = "0";
            // 
            // label11
            // 
            label11.Image = Properties.Resources.igit1;
            label11.Location = new Point(12, 64);
            label11.Name = "label11";
            label11.Size = new Size(60, 60);
            label11.TabIndex = 1;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.WhiteSmoke;
            label12.Location = new Point(78, 80);
            label12.Name = "label12";
            label12.Size = new Size(162, 28);
            label12.TabIndex = 0;
            label12.Text = "Returned Books";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Dashboard";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Panel panel3;
        private Panel panel6;
        private Label label10;
        private Label label11;
        private Label label12;
        private Panel panel5;
        private Label label7;
        private Label label8;
        private Label label9;
        private Panel panel4;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}
