﻿namespace LibraryManagementSystem
{
    partial class Mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            label5 = new Label();
            logoutbtn = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            panel3 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 0, 70);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1100, 35);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.WhiteSmoke;
            label2.Location = new Point(11, 3);
            label2.Name = "label2";
            label2.Size = new Size(114, 28);
            label2.TabIndex = 1;
            label2.Text = "Main Form";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Lucida Sans Unicode", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(1066, 9);
            label1.Name = "label1";
            label1.Size = new Size(22, 22);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(46, 0, 70);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label5);
            panel2.Controls.Add(logoutbtn);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 35);
            panel2.Name = "panel2";
            panel2.Size = new Size(250, 565);
            panel2.TabIndex = 2;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.WhiteSmoke;
            label5.Location = new Point(63, 520);
            label5.Name = "label5";
            label5.Size = new Size(68, 21);
            label5.TabIndex = 3;
            label5.Text = "Log Out";
            // 
            // logoutbtn
            // 
            logoutbtn.Cursor = Cursors.Hand;
            logoutbtn.FlatAppearance.MouseDownBackColor = Color.Orchid;
            logoutbtn.FlatAppearance.MouseOverBackColor = Color.Orchid;
            logoutbtn.FlatStyle = FlatStyle.Flat;
            logoutbtn.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            logoutbtn.ForeColor = Color.WhiteSmoke;
            logoutbtn.Image = Properties.Resources.bleh;
            logoutbtn.Location = new Point(12, 508);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(45, 45);
            logoutbtn.TabIndex = 8;
            logoutbtn.UseVisualStyleBackColor = true;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button4.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.WhiteSmoke;
            button4.Image = Properties.Resources.utot;
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(26, 347);
            button4.Name = "button4";
            button4.Size = new Size(200, 45);
            button4.TabIndex = 7;
            button4.Text = "   RETURN BOOKS";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button3.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.WhiteSmoke;
            button3.Image = Properties.Resources.memaa;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(26, 296);
            button3.Name = "button3";
            button3.Size = new Size(200, 45);
            button3.TabIndex = 6;
            button3.Text = "ISSUE BOOKS";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button2.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.WhiteSmoke;
            button2.Image = Properties.Resources._6771580_book_education_learning_school_science_icon1;
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(26, 245);
            button2.Name = "button2";
            button2.Size = new Size(200, 45);
            button2.TabIndex = 5;
            button2.Text = "ADD BOOKS";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button1.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.WhiteSmoke;
            button1.Location = new Point(26, 194);
            button1.Name = "button1";
            button1.Size = new Size(200, 45);
            button1.TabIndex = 4;
            button1.Text = "DASHBOARD";
            button1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.WhiteSmoke;
            label4.Location = new Point(53, 138);
            label4.Name = "label4";
            label4.Size = new Size(144, 21);
            label4.TabIndex = 3;
            label4.Text = "Welcome, Admin";
            // 
            // label3
            // 
            label3.Image = Properties.Resources.igit;
            label3.Location = new Point(73, 27);
            label3.Name = "label3";
            label3.Size = new Size(100, 100);
            label3.TabIndex = 3;
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(250, 35);
            panel3.Name = "panel3";
            panel3.Size = new Size(850, 565);
            panel3.TabIndex = 9;
            // 
            // Mainform
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 600);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Mainform";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Mainform";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Panel panel2;
        private Label label3;
        private Label label4;
        private Button button1;
        private Button button2;
        private Button button4;
        private Button button3;
        private Button logoutbtn;
        private Label label5;
        private Panel panel3;
    }
}