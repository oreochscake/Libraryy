﻿namespace LibraryManagementSystem
{
    partial class ReturnedBooks
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            textBox4 = new TextBox();
            label5 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            textBox6 = new TextBox();
            label7 = new Label();
            textBox7 = new TextBox();
            label8 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(textBox7);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(textBox6);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(18, 22);
            panel1.Name = "panel1";
            panel1.Size = new Size(291, 526);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonHighlight;
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(315, 22);
            panel2.Name = "panel2";
            panel2.Size = new Size(547, 526);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(13, 17);
            label1.Name = "label1";
            label1.Size = new Size(207, 28);
            label1.TabIndex = 0;
            label1.Text = "All Issued Books";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(26, 70);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(496, 436);
            dataGridView1.TabIndex = 1;
            dataGridView1.CellContentClick += this.dataGridView1_CellContentClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century", 9F);
            label2.Location = new Point(7, 151);
            label2.Name = "label2";
            label2.Size = new Size(71, 18);
            label2.TabIndex = 0;
            label2.Text = "Issue ID:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(77, 142);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(209, 27);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(77, 175);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(209, 27);
            textBox2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century", 9F);
            label3.Location = new Point(24, 179);
            label3.Name = "label3";
            label3.Size = new Size(53, 18);
            label3.TabIndex = 2;
            label3.Text = "Name:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(77, 212);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(209, 27);
            textBox3.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century", 9F);
            label4.Location = new Point(3, 216);
            label4.Name = "label4";
            label4.Size = new Size(79, 18);
            label4.TabIndex = 4;
            label4.Text = "Contact #:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(77, 245);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(209, 27);
            textBox4.TabIndex = 7;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century", 9F);
            label5.Location = new Point(24, 249);
            label5.Name = "label5";
            label5.Size = new Size(54, 18);
            label5.TabIndex = 6;
            label5.Text = "Email:";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(90, 278);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(196, 27);
            textBox5.TabIndex = 9;
            textBox5.TextChanged += this.textBox5_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century", 9F);
            label6.Location = new Point(3, 282);
            label6.Name = "label6";
            label6.Size = new Size(86, 18);
            label6.TabIndex = 8;
            label6.Text = "Book Title:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(107, 344);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(179, 27);
            textBox6.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century", 9F);
            label7.Location = new Point(3, 348);
            label7.Name = "label7";
            label7.Size = new Size(98, 18);
            label7.TabIndex = 10;
            label7.Text = "Book Issued:";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(94, 311);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(196, 27);
            textBox7.TabIndex = 13;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century", 9F);
            label8.Location = new Point(24, 315);
            label8.Name = "label8";
            label8.Size = new Size(62, 18);
            label8.TabIndex = 12;
            label8.Text = "Author:";
            label8.Click += label8_Click;
            // 
            // ReturnedBooks
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "ReturnedBooks";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private DataGridView dataGridView1;
        private TextBox textBox4;
        private Label label5;
        private TextBox textBox3;
        private Label label4;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox5;
        private Label label6;
        private TextBox textBox7;
        private Label label8;
        private TextBox textBox6;
        private Label label7;
    }
}
