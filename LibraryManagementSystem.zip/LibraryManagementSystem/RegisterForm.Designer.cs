﻿namespace LibraryManagementSystem
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            signin_Btn = new Button();
            label6 = new Label();
            label5 = new Label();
            register_showpass = new CheckBox();
            register_btn = new Button();
            register_password = new TextBox();
            label4 = new Label();
            register_username = new TextBox();
            label3 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            register_email = new TextBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // signin_Btn
            // 
            signin_Btn.BackColor = Color.Plum;
            signin_Btn.Cursor = Cursors.Hand;
            signin_Btn.FlatAppearance.BorderSize = 0;
            signin_Btn.FlatAppearance.MouseDownBackColor = Color.Violet;
            signin_Btn.FlatAppearance.MouseOverBackColor = Color.Violet;
            signin_Btn.FlatStyle = FlatStyle.Flat;
            signin_Btn.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            signin_Btn.Location = new Point(69, 488);
            signin_Btn.Name = "signin_Btn";
            signin_Btn.Size = new Size(209, 25);
            signin_Btn.TabIndex = 22;
            signin_Btn.Text = "SIGN IN";
            signin_Btn.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(116, 465);
            label6.Name = "label6";
            label6.Size = new Size(113, 20);
            label6.TabIndex = 12;
            label6.Text = "Create Account";
            // 
            // label5
            // 
            label5.Image = Properties.Resources.book2;
            label5.Location = new Point(116, 38);
            label5.Name = "label5";
            label5.Size = new Size(70, 55);
            label5.TabIndex = 21;
            // 
            // register_showpass
            // 
            register_showpass.AutoSize = true;
            register_showpass.Location = new Point(160, 371);
            register_showpass.Name = "register_showpass";
            register_showpass.Size = new Size(132, 24);
            register_showpass.TabIndex = 20;
            register_showpass.Text = "Show Password";
            register_showpass.UseVisualStyleBackColor = true;
            register_showpass.CheckedChanged += register_showpass_CheckedChanged;
            // 
            // register_btn
            // 
            register_btn.BackColor = Color.Plum;
            register_btn.Cursor = Cursors.Hand;
            register_btn.FlatAppearance.BorderSize = 0;
            register_btn.FlatAppearance.MouseDownBackColor = Color.Violet;
            register_btn.FlatAppearance.MouseOverBackColor = Color.Violet;
            register_btn.FlatStyle = FlatStyle.Flat;
            register_btn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            register_btn.Location = new Point(69, 410);
            register_btn.Name = "register_btn";
            register_btn.Size = new Size(209, 40);
            register_btn.TabIndex = 19;
            register_btn.Text = "REGISTER";
            register_btn.UseVisualStyleBackColor = false;
            register_btn.Click += register_btn_Click;
            // 
            // register_password
            // 
            register_password.Location = new Point(27, 335);
            register_password.Multiline = true;
            register_password.Name = "register_password";
            register_password.PasswordChar = '*';
            register_password.Size = new Size(265, 30);
            register_password.TabIndex = 18;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Constantia", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(27, 310);
            label4.Name = "label4";
            label4.Size = new Size(97, 22);
            label4.TabIndex = 17;
            label4.Text = "Password:";
            // 
            // register_username
            // 
            register_username.Location = new Point(27, 255);
            register_username.Multiline = true;
            register_username.Name = "register_username";
            register_username.Size = new Size(265, 30);
            register_username.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Constantia", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(27, 230);
            label3.Name = "label3";
            label3.Size = new Size(104, 22);
            label3.TabIndex = 15;
            label3.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(69, 93);
            label2.Name = "label2";
            label2.Size = new Size(180, 23);
            label2.TabIndex = 14;
            label2.Text = "Registration Form";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.book1;
            pictureBox2.Location = new Point(150, 82);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(0, 0);
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Lucida Sans Unicode", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(291, 9);
            label1.Name = "label1";
            label1.Size = new Size(22, 21);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 0, 70);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(320, 35);
            panel1.TabIndex = 23;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 62);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // register_email
            // 
            register_email.Location = new Point(27, 182);
            register_email.Multiline = true;
            register_email.Name = "register_email";
            register_email.Size = new Size(265, 30);
            register_email.TabIndex = 25;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Constantia", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(27, 157);
            label7.Name = "label7";
            label7.Size = new Size(137, 22);
            label7.TabIndex = 24;
            label7.Text = "Email Address:";
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(320, 525);
            Controls.Add(register_email);
            Controls.Add(label7);
            Controls.Add(panel1);
            Controls.Add(signin_Btn);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(register_showpass);
            Controls.Add(register_btn);
            Controls.Add(register_password);
            Controls.Add(label4);
            Controls.Add(register_username);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RegisterForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RegisterForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button signin_Btn;
        private Label label6;
        private Label label5;
        private CheckBox register_showpass;
        private Button register_btn;
        private TextBox register_password;
        private Label label4;
        private TextBox register_username;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox2;
        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private TextBox register_email;
        private Label label7;
    }
}